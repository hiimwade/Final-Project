from tkinter import *
import apod_desktop

# Initialize the image cache
apod_desktop.init_apod_cache()

# TODO: Create the GUI
root = Tk()
root.geometry('600x400')

root.mainloop()